package sk.tuke.kpi.oop.game.actions;

import org.jetbrains.annotations.Nullable;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Disposable;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.actions.AbstractAction;
import sk.tuke.kpi.oop.game.items.Usable;

public class Use<T extends  Actor> extends AbstractAction<T> {
    private Usable<T> usable;
    private T ripley;
    @Override
    public void execute(float deltaTime) {
        if (getActor()==null){
            setDone(true);
            return;
        }
        ripley = getActor();
        usable.useWith(ripley);
        setDone(true);
    }
    public Use(Usable<T> usable){
        this.usable = usable;
    }
    @Nullable
    @Override
    public T getActor() {
        return ripley;
    }
    @Override
    public void setActor(T actor) {
        this.ripley = actor;
    }
    public Disposable scheduleOnIntersectingWith(Actor mediatingActor) {
        Scene scene = mediatingActor.getScene();
        if (scene == null) return null;
        Class<T> usingActorClass = usable.getUsingActorClass();

        for (Actor actor : scene) {
            if (mediatingActor.intersects(actor) && usingActorClass.isInstance(actor)) {
                return this.scheduleOn(usingActorClass.cast(actor));
            }
        }
        return null;
    }
}
