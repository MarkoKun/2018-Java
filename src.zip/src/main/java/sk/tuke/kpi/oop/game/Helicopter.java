/*
package sk.tuke.kpi.oop.game;
import sk.tuke.kpi.gamelib.actions.Invoke;

import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.gamelib.framework.Player;
import sk.tuke.kpi.gamelib.framework.AbstractActor;



public class Helicopter extends AbstractActor {
    private Player player;
    public Helicopter(){
        setAnimation(new Animation("sprites/heli.png", 64, 64,0.1f,Animation.PlayMode.LOOP_PINGPONG));
    }
    public void searchAndDestroy(){
        if (getScene().getFirstActorByName("Player")==null) {
            return;
        }
        player = (Player) getScene().getFirstActorByName("Player");
        new Loop<>(new Invoke<>(this::followPlayer)).scheduleOn(this);

    }
    private void followPlayer(){
        if (player.getPosX()!=getPosX() || player.getPosY()!=getPosY()){
            if (getPosX()>player.getPosX()) {
                setPosition(getPosX() - 1, getPosY());
            }else {
                setPosition(getPosX() + 1, getPosY());
            }
            if (getPosY()>player.getPosY()) {
                setPosition(getPosX(), getPosY() - 1);
            }else {
                setPosition(getPosX(), getPosY() + 1);
            }
        }
        if (player.getPosX()==getPosX() && player.getPosY()==getPosY()){
            player.setEnergy(player.getEnergy()-1);
        }

    }
}
*/
