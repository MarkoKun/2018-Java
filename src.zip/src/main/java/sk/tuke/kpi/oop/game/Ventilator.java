package sk.tuke.kpi.oop.game;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.gamelib.messages.Topic;
import sk.tuke.kpi.oop.game.openables.Door;

public class Ventilator extends AbstractActor implements Repairable {
    public static final Topic<Ventilator> VENTILATOR1_ON = Topic.create("ventilator1 on", Ventilator.class);
    public static final Topic<Ventilator> VENTILATOR2_ON = Topic.create("ventilator2 on", Ventilator.class);
    public static final Topic<Ventilator> VENTILATOR3_ON = Topic.create("ventilator3 on", Ventilator.class);
    public static final Topic<Ventilator> VENTILATOR4_ON = Topic.create("ventilator4 on", Ventilator.class);
    private Animation ventilatorr = new Animation("sprites/ventilator.png", 32, 32, 0.1f, Animation.PlayMode.LOOP);
    private String acType;

    public Ventilator(String type) {
        this.acType = type;
        setAnimation(ventilatorr);
        ventilatorr.pause();
    }

    @Override
    public boolean repair() {
        switch (acType) {
            case "bd1":
                getScene().getMessageBus().publish(VENTILATOR1_ON, this);
                ventilatorr.play();
                getScene().getGame().getOverlay().drawText("Good job, fix them all !!!", 300, 400).showFor(2);

                return true;
            case "bd2":
                getScene().getMessageBus().publish(VENTILATOR2_ON, this);
                ventilatorr.play();
                getScene().getGame().getOverlay().drawText("Good job, fix them all !!!", 300, 400).showFor(2);

                return true;
            case "bd3":
                getScene().getMessageBus().publish(VENTILATOR3_ON, this);
                ventilatorr.play();
                getScene().getGame().getOverlay().drawText("Good job, fix them all !!!", 300, 400).showFor(2);

                return true;
            case "bd4":
                getScene().getMessageBus().publish(VENTILATOR4_ON, this);
                ventilatorr.play();
                getScene().getGame().getOverlay().drawText("Good job, now let's check room with alien eggs inside and try to press some numbers !!!", 10, 400).showFor(5);

                return true;
        }
        return true;
    }
}
