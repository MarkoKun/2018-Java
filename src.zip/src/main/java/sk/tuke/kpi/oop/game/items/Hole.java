package sk.tuke.kpi.oop.game.items;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.actions.Wait;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.characters.Alive;
import sk.tuke.kpi.oop.game.characters.Enemy;
import sk.tuke.kpi.oop.game.characters.Health;
import sk.tuke.kpi.oop.game.characters.Ripley;

public class Hole extends AbstractActor implements Enemy {
    private Animation holeAnimation = new sk.tuke.kpi.gamelib.graphics.Animation("sprites/hole.png", 32, 32, 0.7f, Animation.PlayMode.LOOP_PINGPONG);

    public Hole() {
        setAnimation(holeAnimation);
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);

        /*new Loop<>(
            new ActionSequence<>(
                new Invoke<>(this::deadActor))
        ).scheduleOn(this);*/

        new Loop<>(
            new ActionSequence<>(
                new Invoke<>(this::drainActor),
                new Wait<>(2))
        ).scheduleOn(this);
    }

    private void drainActor() {
        Scene scene = getScene();

        for (Actor actor : scene.getActors()) {
            if (actor instanceof Alive && actor.intersects(this)) {
                if (actor instanceof Enemy) {
                    return;
                }
                ((Alive) actor).getHealth().drain(50);
            }
        }
    }

   /* private void deadActor(){
        if (getScene().getFirstActorByType(Ripley.class).getHealth().getValue() == 0){
            getScene().getFirstActorByType(Ripley.class).setSpeed(0);
            getScene().getFirstActorByType(Ripley.class).deadRipleyAnimation();
        }
    }*/
}
