package sk.tuke.kpi.oop.game;
import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;


public class Cooler extends AbstractActor implements Switchable{
    //private int tempdecrement;
    private boolean isWorking;
    private Animation onCooler;
    private Animation offCooler;
    private Reactor reactor;


    public Cooler(Reactor reactor) {
        this.reactor = reactor;
        isWorking = false;
        onCooler = new Animation("sprites/fan.png", 32, 32, 0.2f, Animation.PlayMode.LOOP_PINGPONG);
        offCooler = new Animation("sprites/fan.png", 32, 32,0.2f, Animation.PlayMode.LOOP_PINGPONG);
        setAnimation(offCooler);
        getAnimation().stop();
    }



    @Override
    public void turnOn() {
        isWorking = true;
        setAnimation(onCooler);
        getAnimation().play();
    }

    @Override
    public void turnOff() {
        isWorking = false;
        setAnimation(offCooler);
        getAnimation().stop();
    }

    @Override
    public boolean isOn() {
        return isWorking;
    }

    public void coolReactor() {
        if (isOn()) {
            if (reactor == null) {
                return;
            } else {
                reactor.decreaseTemperature(1);

            }
        }
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        new Loop<>(new Invoke<>(this::coolReactor)).scheduleOn(this);

    }
}
