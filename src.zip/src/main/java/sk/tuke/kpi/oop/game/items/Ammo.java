package sk.tuke.kpi.oop.game.items;

import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.characters.Armed;

public class Ammo extends AbstractActor implements Usable<Armed> {

    private Animation ammmo = new Animation("sprites/ammo.png", 16, 16);
    public Ammo(){
        setAnimation(ammmo);
    }

    @Override
    public void useWith(Armed actor) {
        if (actor == null) {
            return;
        }
        if (actor.getFirearm().getAmmo() > 500) {
            actor.getFirearm().reload(500);
        }
        actor.getFirearm().reload(50);
        Scene scene = getScene();
        assert scene != null;
        scene.removeActor(this);
    }

    @Override
    public Class<Armed> getUsingActorClass() {
        return Armed.class;
    }

}
