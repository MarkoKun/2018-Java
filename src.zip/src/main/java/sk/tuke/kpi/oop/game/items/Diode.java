package sk.tuke.kpi.oop.game.items;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.actions.Wait;
import sk.tuke.kpi.gamelib.actions.When;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.Ventilator;
import sk.tuke.kpi.oop.game.characters.Ripley;

public class Diode extends AbstractActor {
    private Animation animationG = new Animation("sprites/button_green.png", 16, 16);
    private String myName;
    private int number = 0;

    public Diode(String name) {
        this.myName = name;
        Animation animationR = new Animation("sprites/button_red.png", 16, 16);
        setAnimation(animationR);
    }

    /* public void change(){
         Diode diode = new Diode();
         this.setAnimation(animationG);
     }*/
    public Diode getDiode() {
        return this;
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        getScene().getMessageBus().subscribe(Ventilator.VENTILATOR1_ON, diode -> change1());
        getScene().getMessageBus().subscribe(Ventilator.VENTILATOR2_ON, diode1 -> change2());
        getScene().getMessageBus().subscribe(Ventilator.VENTILATOR3_ON, diode2 -> change3());
        getScene().getMessageBus().subscribe(Ventilator.VENTILATOR4_ON, diode3 -> change4());

        /*Ripley myRipley = getScene().getFirstActorByType(Ripley.class);
        new When<>(
            (action) -> door.intersects(ripley) && !door.isOpen(),
            new ActionSequence<>(
                new Invoke<Actor>(() -> door.useWith(ripley)),
                new Wait<>(2),
                new Invoke<>(door::close)
            )

        ).scheduleOn(this);*/
        /*for (Actor actor : scene.getActors()){
            if (actor instanceof WinSwich && actor.intersects(myRipley));
            scene.getGame().stop();

        }*/
       /* if (getScene().getFirstActorByType(Ripley.class).intersects(getScene().getFirstActorByType(WinSwich.class))&&getNumber()==4){
            scene.getGame().stop();
        }*/
        /*new Loop<>(
            new Invoke<>(this::change)
        ).scheduleOn(this);*/
    }
    //96 125

    public void change1() {
        if (myName.equals("diode1")) {
            this.setAnimation(animationG);
            number++;
        }
    }

    public void change2() {
        if (myName.equals("diode2")) {
            this.setAnimation(animationG);
            number++;
        }
    }

    public void change3() {
        if (myName.equals("diode3")) {
            this.setAnimation(animationG);
            number++;
        }
    }

    public void change4() {
        if (myName.equals("diode4")) {
            this.setAnimation(animationG);
            number++;
        }
    }

    public int getNumber() {
        return number;
    }

}

