/*package sk.tuke.kpi.oop.game.scenarios;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.*;
import sk.tuke.kpi.gamelib.actions.When;
import sk.tuke.kpi.oop.game.Direction;
import sk.tuke.kpi.oop.game.controllers.MovableController;
import sk.tuke.kpi.oop.game.actions.Use;
import sk.tuke.kpi.oop.game.characters.Ripley;
import sk.tuke.kpi.oop.game.actions.Move;
import sk.tuke.kpi.oop.game.controllers.CollectorController;
import sk.tuke.kpi.oop.game.items.*;

public class FirstSteps implements SceneListener {
    private Move move;
    private Input input;
    private Backpack backpack = new Backpack("Ripley's backpack", 10);

    private MovableController keyboardController;
    private CollectorController collectorController;
    private Hammer hammer;
    Ripley ripley = new Ripley();
    private FireExtinguisher fireExtinguisher;
    @Override
    public void sceneInitialized(@NotNull Scene scene) {
        move = new Move(Direction.SOUTH, 0);
        scene.addActor(ripley,50,0);
        move.scheduleOn(ripley);
        keyboardController = new MovableController( ripley);
        collectorController = new CollectorController(ripley);
        input = scene.getInput();
        input.registerListener(keyboardController);
        input.registerListener(collectorController);
        Energy energy = new Energy();
        scene.addActor(energy);
        Ammo ammo = new Ammo();
        Ammo ammo1 = new Ammo();
        scene.addActor(ammo,150,5);
        scene.addActor(ammo1,100,5);
        hammer = new Hammer();
        scene.addActor(hammer, 200,10);
        fireExtinguisher = new FireExtinguisher();
        scene.addActor(fireExtinguisher,300,10);
        new When<>(
            (action) -> energy.intersects(ripley),
            new Use<>(energy)
        ).scheduleOn(ripley);

        new When<>(
            (action) -> ammo.intersects(ripley),
            new Use<>(ammo)
        ).scheduleOn(ripley);

        new When<>(
            (action) -> ammo1.intersects(ripley),
            new Use<>(ammo1)
        ).scheduleOn(ripley);




    }
    public void sceneUpdating(Scene scene){
        int windowHeight = scene.getGame().getWindowSetup().getHeight();
        int topOffset = GameApplication.STATUS_LINE_OFFSET;
        int yTextPos = windowHeight - topOffset;
        scene.getGame().getOverlay().drawText("Energy : "+ripley.getEnergy(),100 ,yTextPos);
        scene.getGame().getOverlay().drawText("Ammo : "+ripley.getAmmo(),250 ,yTextPos);
        Game game = scene.getGame();
        game.pushActorContainer(ripley.getContainer());
    }
}
*/
