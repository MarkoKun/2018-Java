package sk.tuke.kpi.oop.game.items;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.Ventilator;
import sk.tuke.kpi.oop.game.characters.Ripley;

public class WinSwich extends AbstractActor implements Usable<Ripley> {

    private int justNum;
    private int magic;

    public WinSwich() {
        setAnimation(new Animation("sprites/switch.png", 16, 16));
        winNow = false;
    }

    private boolean winNow;

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        isSolved();
        getScene().getMessageBus().subscribe(Ventilator.VENTILATOR1_ON, diode -> increase());
        getScene().getMessageBus().subscribe(Ventilator.VENTILATOR2_ON, diode1 -> increase());
        getScene().getMessageBus().subscribe(Ventilator.VENTILATOR3_ON, diode2 -> increase());
        getScene().getMessageBus().subscribe(Ventilator.VENTILATOR4_ON, diode3 -> increase());
        Ripley ripley = scene.getFirstActorByType(Ripley.class);
        new Loop<>(
            new ActionSequence<>(
                new Invoke<>(() -> this.helper(ripley)))
        ).scheduleOn(ripley);
    }

    public void helper(Ripley ripley) {
        for (Actor actor : ripley.getScene().getActors()) {
            if (actor instanceof Ripley && actor.intersects(this) && getJustNum() == 4 && getMagic() == 6) {
                //getScene().getGame().getOverlay().drawAnimation(new Animation("sprites/popup_level_done", 288, 128),ripley.getPosX(),ripley.getPosY());
                ripley.setSpeed(0);
                getScene().getGame().getOverlay().drawText("Level Completed, Awesome !!!\nPress ESCAPE to end game !!!", 300, 400).showFor(100000);
            }
        }
    }

    public void increase() {
        justNum++;
    }

    public void setMagic() {
        magic++;
    }

    public int getJustNum() {
        return justNum;
    }

    public void isSolved() {
        getScene().getMessageBus().subscribe(SecretTile.SecretTile1_ON, bla1 -> setMagic());
        getScene().getMessageBus().subscribe(SecretTile.SecretTile2_ON, bla1 -> setMagic());
        getScene().getMessageBus().subscribe(SecretTile.SecretTile3_ON, bla3 -> setMagic());
        getScene().getMessageBus().subscribe(SecretTile.SecretTile4_ON, bla4 -> setMagic());
        getScene().getMessageBus().subscribe(SecretTile.SecretTile5_ON, bla5 -> setMagic());
        getScene().getMessageBus().subscribe(SecretTile.SecretTile6_ON, bla6 -> setMagic());


    }

    public int getMagic() {
        return magic;
    }

    @Override
    public void useWith(Ripley actor) {
        helper(actor);
    }

    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }
}
