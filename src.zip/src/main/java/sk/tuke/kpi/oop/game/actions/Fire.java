package sk.tuke.kpi.oop.game.actions;

import sk.tuke.kpi.gamelib.framework.actions.AbstractAction;
import sk.tuke.kpi.oop.game.Direction;
import sk.tuke.kpi.oop.game.characters.Armed;
import sk.tuke.kpi.oop.game.weapons.Fireable;

public class Fire<A extends Armed> extends AbstractAction<A> {

    @Override
    public void execute(float deltaTime) {
        if (getActor() == null) {
            setDone(true);
            return;
        }
        if (getActor() != null && getActor().getFirearm() == null) {
            setDone(true);
            return;
        }
        Fireable fireable = ((Armed) getActor()).getFirearm().fire();
        if (fireable == null) {
            setDone(true);
            return;
        }
        getActor().getScene().addActor(fireable, getActor().getPosX() + (getActor().getWidth() / 4), getActor().getPosY() + (getActor().getHeight() / 4));
        new Move<>(Direction.fromAngle(getActor().getAnimation().getRotation()), 1000).scheduleOn(fireable);
        setDone(true);
    }
}
