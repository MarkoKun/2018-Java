package sk.tuke.kpi.oop.game.items;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.actions.Wait;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.gamelib.map.MapTile;
import sk.tuke.kpi.oop.game.characters.*;
import sk.tuke.kpi.oop.game.openables.Openable;

import java.util.List;
import java.util.Random;

public class LaserDoor extends AbstractActor implements Alive, Openable, Usable<Ripley> {
    private Animation animation = new Animation("sprites/laser.png", 16, 48, 0.1f, Animation.PlayMode.LOOP_PINGPONG);
    private Animation body1 = new Animation("sprites/body.png", 64, 48);
    private boolean opened;
    private Health health;

    public LaserDoor() {
        setAnimation(animation);
        animation.play();
        animation.setRotation(90);
        health = new Health(1000);
    }

    @Override
    public Health getHealth() {
        return health;
    }

    @Override
    public void open() {
        Random random = new Random();
        float num = random.nextFloat() * (360 - 1) + 1;
        opened = true;
        getScene().getMap().getTile(this.getPosX() / 16 + 1, this.getPosY() / 16).setType(MapTile.Type.CLEAR);
        getScene().getMap().getTile(this.getPosX() / 16 + 2, this.getPosY() / 16).setType(MapTile.Type.CLEAR);
        getScene().getMap().getTile(this.getPosX() / 16 + 3, this.getPosY() / 16).setType(MapTile.Type.CLEAR);
        getScene().getMap().getTile(this.getPosX() / 16 + 1, this.getPosY() / 16 + 1).setType(MapTile.Type.CLEAR);
        getScene().getMap().getTile(this.getPosX() / 16 + 2, this.getPosY() / 16 + 1).setType(MapTile.Type.CLEAR);
        getScene().getMap().getTile(this.getPosX() / 16 + 3, this.getPosY() / 16 + 1).setType(MapTile.Type.CLEAR);
        getScene().getMap().getTile(this.getPosX() / 16 + 1, this.getPosY() / 16 + 2).setType(MapTile.Type.CLEAR);
        getScene().getMap().getTile(this.getPosX() / 16 + 2, this.getPosY() / 16 + 2).setType(MapTile.Type.CLEAR);
        getScene().getMap().getTile(this.getPosX() / 16 + 3, this.getPosY() / 16 + 2).setType(MapTile.Type.CLEAR);
        setAnimation(body1);
        body1.setRotation(num);

    }

    @Override
    public void close() {
        opened = false;
        getScene().getMap().getTile(this.getPosX() / 16 + 1, this.getPosY() / 16).setType(MapTile.Type.WALL);
        getScene().getMap().getTile(this.getPosX() / 16 + 2, this.getPosY() / 16).setType(MapTile.Type.WALL);
        getScene().getMap().getTile(this.getPosX() / 16 + 3, this.getPosY() / 16).setType(MapTile.Type.WALL);
        getScene().getMap().getTile(this.getPosX() / 16 + 1, this.getPosY() / 16 + 1).setType(MapTile.Type.WALL);
        getScene().getMap().getTile(this.getPosX() / 16 + 2, this.getPosY() / 16 + 1).setType(MapTile.Type.WALL);
        getScene().getMap().getTile(this.getPosX() / 16 + 3, this.getPosY() / 16 + 1).setType(MapTile.Type.WALL);
        getScene().getMap().getTile(this.getPosX() / 16 + 1, this.getPosY() / 16 + 2).setType(MapTile.Type.WALL);
        getScene().getMap().getTile(this.getPosX() / 16 + 2, this.getPosY() / 16 + 2).setType(MapTile.Type.WALL);
        getScene().getMap().getTile(this.getPosX() / 16 + 3, this.getPosY() / 16 + 2).setType(MapTile.Type.WALL);


    }

    @Override
    public boolean isOpen() {
        return opened;
    }

    @Override
    public void useWith(Ripley actor) {
        if (isOpen()) {
            close();
        } else {
            open();
        }
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        this.close();
        new Loop<>(
            new ActionSequence<>(
                new Invoke<>(this::drainHP),
                new Wait<>(0.1f))
        ).scheduleOn(this);
        scene.getMessageBus().subscribe(Desk.LaserOffline, bla -> open());

    }

    public void drainHP() {
        List<Actor> list = getScene().getActors();
        if (!opened) {
            for (Actor someActor : list) {
                if (someActor instanceof Alive && someActor.intersects(this)) {
                    ((Alive) someActor).getHealth().drain(10);
                }
            }
        }
    }

    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }
}
