package sk.tuke.kpi.oop.game;

public interface EnergyConsumer {
    void setPowered(boolean powered);
}
