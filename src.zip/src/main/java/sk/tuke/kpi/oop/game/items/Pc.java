package sk.tuke.kpi.oop.game.items;

import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.characters.Ripley;
import sk.tuke.kpi.oop.game.weapons.Bullet;

public class Pc extends AbstractActor implements Usable<Ripley> {
    private Animation animation = new Animation("sprites/computer.png", 80, 48, 0.1f, Animation.PlayMode.LOOP_PINGPONG);
    //public static final Topic<Pc> PC_USE = Topic.create("pc used", Pc.class);

    public Pc() {
        setAnimation(animation);
    }

    @Override
    public void useWith(Ripley actor) {
        if (actor != null) {
            if (actor.getMoney() > 1000) {
                //getScene().getMessageBus().publish(PC_USE, this);
                actor.setPosition(140, 575);
                new Loop<>(
                    new Invoke<>(this::changeBulletAnimation)
                ).scheduleOn(this);
            }
        }
    }

    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }

    private void changeBulletAnimation() {

        for (Actor actor : getScene().getActors()) {
            if (actor instanceof Bullet) {
                ((Bullet) actor).setAnim();
            }
        }
    }
}
