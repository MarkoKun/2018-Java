package sk.tuke.kpi.oop.game.controllers;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Input;
import sk.tuke.kpi.gamelib.KeyboardListener;
import sk.tuke.kpi.oop.game.Direction;
import sk.tuke.kpi.oop.game.Movable;
import sk.tuke.kpi.oop.game.actions.Move;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MovableController implements KeyboardListener {
    private Set<Input.Key> hash_Set;
    private Move<Movable> move;
    private Movable movable;
    private Map<Input.Key, Direction> keyDirectionMap = Map.ofEntries(
        Map.entry(Input.Key.UP, Direction.NORTH),
        Map.entry(Input.Key.DOWN, Direction.SOUTH),
        Map.entry(Input.Key.LEFT, Direction.WEST),
        Map.entry(Input.Key.RIGHT, Direction.EAST)
    );

    public MovableController(Movable movable) {

        this.movable = movable;
        this.move = new Move<>(Direction.NORTH);
        move.setActor(movable);
        hash_Set = new HashSet<>();
    }

    /*private void addSet(Input.Key key){
        if (keyDirectionMap.containsKey(key)){
            hash_Set.add(key);
            actualKey = key;
        }
    }*/

    @Override
    public void keyPressed(@NotNull Input.Key key) {
        if (keyDirectionMap.containsKey(key)){
            hash_Set.add(key);
            if (hash_Set.size()==1){
                move = new Move<>(keyDirectionMap.get(key), Float.MAX_VALUE);
                     move.scheduleOn(movable);
                }
            /*if (hash_Set.size() == 2) {
                for (Input.Key anotherkey : hash_Set) {
                    if (key != anotherkey){
                        Direction direction = keyDirectionMap.get(key).combine(keyDirectionMap.get(anotherkey));
                        move = new Move<>(direction, Float.MAX_VALUE);
                        move.scheduleOn(movable);
                    }
                }

            }*/
        }


    }
    @Override
    public void keyReleased(@NotNull Input.Key key) {
        if (keyDirectionMap.containsKey(key)) {
            move.stop();
            hash_Set.remove(key);
            for (Input.Key key1 : hash_Set) {
                move.stop();
                hash_Set.remove(key1);

            }

        }
    }
}
