/*
package sk.tuke.kpi.oop.game.items;

import sk.tuke.kpi.gamelib.Actor;

public interface ChangeAble extends Actor {
    void changeAnim();
}
*/
