package sk.tuke.kpi.oop.game.items;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.gamelib.map.MapTile;
import sk.tuke.kpi.oop.game.characters.Casher;
import sk.tuke.kpi.oop.game.openables.Openable;

public class ExpensiveDoor extends AbstractActor implements Usable<Actor>, Openable {
    private Animation animation = new Animation("sprites/vdoor_strong.png", 16, 32, 0.1f, Animation.PlayMode.ONCE);
    private boolean opened;

    public ExpensiveDoor() {
        setAnimation(animation);
        animation.setPlayMode(Animation.PlayMode.ONCE);
        animation.stop();
    }

    @Override
    public boolean isOpen() {
        return opened;
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        this.close();
    }

    @Override
    public Class<Actor> getUsingActorClass() {
        return Actor.class;
    }

    @Override
    public void useWith(Actor actor) {
        if (actor != null) {
            if (findCasher(actor).getMoney() >= 1000) {
                findCasher(actor).setMoney(-1000);
                if (isOpen()) {
                    close();
                } else {
                    open();

                }
            }
        }
    }

    @Override
    public void open() {
        opened = true;
        getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16).setType(MapTile.Type.CLEAR);
        getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16 + 1).setType(MapTile.Type.CLEAR);
        animation.setPlayMode(Animation.PlayMode.LOOP_REVERSED);
    }

    @Override
    public void close() {
        opened = false;
        getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16).setType(MapTile.Type.WALL);
        getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16 + 1).setType(MapTile.Type.WALL);
        animation.setPlayMode(Animation.PlayMode.ONCE);
    }

    public Casher findCasher(Actor actor) {
        for (Actor actor1 : actor.getScene().getActors()) {
            if (actor1 instanceof Casher) {
                return (Casher) actor1;
            }
        }
        return null;
    }
}
