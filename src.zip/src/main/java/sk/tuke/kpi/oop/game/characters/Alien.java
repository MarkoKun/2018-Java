package sk.tuke.kpi.oop.game.characters;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.actions.Wait;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.Movable;
import sk.tuke.kpi.oop.game.behaviours.Behaviour;

import java.util.List;

public class Alien extends AbstractActor implements Movable, Enemy, Alive {
    private Health health;
    private boolean isDead;
    private Behaviour<? super Alien> behaviour;
    private Animation animation = new Animation("sprites/alien.png", 32, 32, 0.1f);
    private int speed;
    public Alien() {
        isDead = false;
        setAnimation(animation);
        health = new Health(100);
        speed = 1;
    }

    public Alien(int healthValue, Behaviour<? super Alien> behaviour) {
        setAnimation(animation);
        health = new Health(healthValue);
        this.behaviour = behaviour;
        isDead = false;
        speed = 1;

    }

    @Override
    public int getSpeed() {
        return speed;
    }

    @Override
    public Health getHealth() {
        return this.health;
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {

        super.addedToScene(scene);
        if (behaviour != null) {
            behaviour.setUp(this);

        }

        new Loop<>(
            new ActionSequence<>(
                new Invoke<>(this::changeAnim),

                new Invoke<>(this::drainHP),
                new Wait<>(0.2f))
        ).scheduleOn(this);

    }

    public void changeAnim() {
        if (this.getHealth().getValue() <= 0) {
            animation.stop();
            isDead = true;
            speed = 0;
            getScene().removeActor(this);
        }
    }

    public void drainHP() {
        if (!isDead) {
            List<Actor> list = getScene().getActors();
            for (Actor someActor : list) {

                if (someActor instanceof Casher && someActor.intersects(this)) {
                    ((Alive) someActor).getHealth().drain(10);
                }
            }
        }
    }
}
