package sk.tuke.kpi.oop.game.actions;

import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.actions.AbstractAction;
import sk.tuke.kpi.oop.game.Keeper;
import sk.tuke.kpi.oop.game.items.Collectible;

import java.util.List;
public class Take<T extends Actor & Collectible> extends AbstractAction<Keeper<T>> {
    private Class<T> item;
    //private Actor actor;

    public Take(Class<T> takableActorsClass) {
        item = takableActorsClass;
        //scene = getScene();
    }

    @Override
    public void execute(float deltaTime) {
        // Ripley ripley = scene.getFirstActorByType(Ripley.class);
        //   private Backpack backpack;
        //    private Object object;

        //   private Keeper keeper;

        if (getActor() == null) {
            setDone(true);
            // isDone();
            return;
        }
        Keeper<T> ripley = getActor();
        Scene scene = getActor().getScene();
        List<Actor> list = scene.getActors();
        for (Actor actor : list) {
            if (ripley.intersects(actor) && item.isInstance(actor)) {
                try {
                    ripley.getContainer().add(item.cast(actor));
                    scene.removeActor(actor);
                } catch (Exception ex) {
                    scene.getGame().getOverlay().drawText(ex.getMessage(), 0, 0).showFor(2);
                  //  finish = true;
               }
            }
        }
       // finish = true;
        setDone(true);

    }

   /* @Override
    public boolean isDone() {
        return finish;
    }

    @Override
    public void reset() {
        finish = false;
    }*/
}
