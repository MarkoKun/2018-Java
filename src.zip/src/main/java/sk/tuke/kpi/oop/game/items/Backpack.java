package sk.tuke.kpi.oop.game.items;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sk.tuke.kpi.gamelib.ActorContainer;

import java.util.*;

public class Backpack implements ActorContainer<Collectible> {
    private List<Collectible> list = new ArrayList<>();
    private int capacity;
    private String name;

    public Backpack(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;

    }

    @Override
    public int getCapacity() {
        return capacity;
    }

    @NotNull
    @Override
    public List<Collectible> getContent() {
        List<Collectible> secondList = new ArrayList<>();
        secondList.addAll(list);
        return secondList;

    }

    @NotNull
    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getSize() {
        return list.size();

    }

    @Override
    public void add(@NotNull Collectible actor) {
        if (getSize() >= getCapacity()) {
            throw new IllegalStateException(name + " is full");
        } else {
            this.list.add(getSize(), actor);
        }
    }

    @Nullable
    @Override
    public Collectible peek() {
        if (getSize() <= 0){
            return null;
        }else {
            return list.get(getSize() - 1);
        }

    }

    @Override
    public void remove(@NotNull Collectible actor) {
        list.remove(actor);

    }

    @Override
    public void shift() {
        /*Collectible actorLast = this.backpack.list.get(counter);
        this.backpack.list.remove(counter);
        Collectible actorFirst = this.backpack.list.get(0);
        this.backpack.list.remove(0);
        this.backpack.list.set(counter, actorFirst);
        this.backpack.list.set(0, actorLast);*/
        Collections.rotate(this.list, 1);


    }

    @NotNull
    @Override
    public Iterator<Collectible> iterator() {

        return list.iterator();
    }


}
