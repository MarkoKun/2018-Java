package sk.tuke.kpi.oop.game.items;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.actions.Wait;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.behaviours.RandomlyMoving;
import sk.tuke.kpi.oop.game.characters.Alien;
import sk.tuke.kpi.oop.game.characters.Alive;
import sk.tuke.kpi.oop.game.characters.Health;
import sk.tuke.kpi.oop.game.characters.Ripley;

public class AlienEggs extends AbstractActor implements Alive {
    private Animation animation = new Animation("sprites/alien_egg.png", 32, 32, 0.1f, Animation.PlayMode.ONCE);
    private Health health;

    public AlienEggs() {
        setAnimation(animation);
        health = new Health(100);
        animation.stop();
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        new Loop<>(
            new ActionSequence<>(
                new Wait<>(3),
                new Invoke<>(this::hunt)
            )
        ).scheduleOn(this);
    }

    @Override
    public Health getHealth() {
        return health;
    }

    public void hunt() {
        if (this.intersects(getScene().getFirstActorByType(Ripley.class))) {
            animation.play();
            getScene().addActor(new Alien(1, new RandomlyMoving()), this.getPosX() + 5, this.getPosY());
        }
    }
}
