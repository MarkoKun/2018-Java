package sk.tuke.kpi.oop.game.items;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.gamelib.messages.Topic;
import sk.tuke.kpi.oop.game.characters.Ripley;

public class Desk extends AbstractActor implements Usable<Ripley> {
    public static final Topic<Desk> LaserOffline = Topic.create("Lasser Offline", Desk.class);
    private Animation animation = new Animation("sprites/desk.png", 48, 48);

    public Desk() {
        setAnimation(animation);
        animation.setRotation(180);
    }

    @Override
    public void useWith(Ripley actor) {
        if (actor != null) {
            actor.getScene().getMessageBus().publish(LaserOffline, this);
        }
    }

    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }
}
