package sk.tuke.kpi.oop.game.characters;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.items.AccessCard;
import sk.tuke.kpi.oop.game.items.Money;
import sk.tuke.kpi.oop.game.items.Usable;

import java.util.Random;

public class Corpse extends AbstractActor implements Usable<Ripley> {
    private Animation animation = new Animation("sprites/body.png", 64, 48, 0.1f);
    private int lives = 1;

    public Corpse() {
        setAnimation(animation);
        animation.stop();
    }

    @Override
    public void useWith(Ripley actor) {
        if (actor != null && lives == 1) {
            actor.getScene().addActor(new AccessCard(), actor.getPosX() + 10, actor.getPosY());
            actor.getScene().addActor(new Money(20), actor.getPosX() + 15, actor.getPosY() - 2);
            actor.setMoney(20);
            lives--;
            Random random = new Random();
            float num = random.nextFloat() * (360 - 1) + 1;
            animation.setRotation(num);
            getScene().getGame().getOverlay().drawText("You have an access card, some doors may be locked for a reason !!!", 125, 400).showFor(3);

            /*animation.play();
            new Wait<Corpse>(0.2f);
            animation.stop();*/
        }

    }

    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }
}
