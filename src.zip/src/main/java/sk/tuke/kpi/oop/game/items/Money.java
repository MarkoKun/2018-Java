package sk.tuke.kpi.oop.game.items;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.characters.Casher;

public class Money extends AbstractActor implements Usable<Casher> {
    private Animation animation = new Animation("sprites/money.png", 16, 16);
    private int money;

    public Money(int money) {
        setAnimation(animation);
    }

    @Override
    public void useWith(Casher actor) {
        if (actor != null) {
            if (actor.intersects(this)) {
                actor.getScene().removeActor(this);
                actor.setMoney(100);
            }
        }
    }

    @Override
    public Class<Casher> getUsingActorClass() {
        return Casher.class;
    }
}
