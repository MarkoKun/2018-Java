package sk.tuke.kpi.oop.game.openables;

import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.oop.game.Keeper;

public class SuperDoor extends Door {
    public SuperDoor(String namee, Orientation orientation) {
        super(namee, orientation);
    }

    @Override
    public void useWith(Actor actor) {
        if (actor != null) {
            for (Actor actor1 : actor.getScene().getActors()) {
                if (actor1 instanceof Keeper<?> && ((Keeper) actor1).getContainer().getSize() > 0) {
                    if (((Keeper) actor1).getContainer().peek().getName().equals("AccessCard")) {
                        open();
                    }
                }
            }
        }
    }
}
