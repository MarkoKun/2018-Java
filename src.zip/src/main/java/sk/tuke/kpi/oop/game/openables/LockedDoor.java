package sk.tuke.kpi.oop.game.openables;

import sk.tuke.kpi.gamelib.Actor;

public class LockedDoor extends Door {
    private boolean locked;


    public LockedDoor(String name, Orientation orientation) {
        super(name, orientation);
       /* getScene().getMap().getTile(this.getPosX()/16, this.getPosY()/16).setType(MapTile.Type.WALL);
        getScene().getMap().getTile(this.getPosX()/16, this.getPosY()/16+1).setType(MapTile.Type.WALL);*/
        locked = true;
        close();
    }
    public void lock(){
        locked = true;
        close();
    }
    public void unlock(){
        locked = false;
        open();
    }
    public boolean isLocked(){
        return locked;
    }

    @Override
    public void useWith(Actor actor) {
        if (actor != null) {
            if (isLocked()){
                unlock();
            }
            if (!isLocked()){
                lock();

            }
        }
    }

    @Override
    public Class<Actor> getUsingActorClass() {
        return Actor.class;
    }
}
