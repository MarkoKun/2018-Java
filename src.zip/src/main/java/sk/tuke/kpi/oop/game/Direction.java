package sk.tuke.kpi.oop.game;


public enum Direction{
    NORTH(0, 1), SOUTH(0, -1), WEST(-1, 0), EAST(1, 0), NONE(0, 0), NORTHEAST(1, 1), NORTHWEST(-1, 1), SOUTHEAST(1, -1), SOUTHWEST(-1, -1);

    private final int dx;
    private final int dy;
    int degrees;
    public int getDx() {
        return dx;
    }

    public int getDy() {
        return dy;
    }

    Direction(int dx, int dy) {
        this.dx=dx;
        this.dy=dy;
    }

    public Direction combine(Direction second) {
        int firstDx = getDx() + second.getDx();
        int firstDy = getDy() + second.getDy();
        if (this.getDy() == second.getDy()) {
            firstDy = getDy();
        }
        if (this.getDx() == second.getDx()) {
            firstDx = getDx();
        }
        for (Direction direction : Direction.values()) {
            if (direction.getDx() == firstDx && direction.getDy() == firstDy) {
                return direction;
            }
        }
        return NONE;
    }

    public float getAngle() {
        if (this == NORTHEAST) {
            degrees = 315;
            return degrees;
        } else if (this == NORTHWEST) {
            degrees = 45;
            return degrees;
        } else if (this == SOUTHEAST) {
            degrees = 225;
            return degrees;
        } else if (this == SOUTHWEST) {
            degrees = 135;
            return degrees;
        } else {
            return getAngelFirst();
        }
    }

    public float getAngelFirst() {
        if (this == NORTH) {
            degrees = 0;
        } else if (this == SOUTH) {
            degrees = 180;
        } else if (this == EAST) {
            degrees = 270;
        } else if (this == WEST) {
            degrees = 90;
        }
        return degrees;
    }

    public static Direction fromAngle(float angle) {

        if (angle == 0f) {
            return Direction.NORTH;
        } else if (angle == 180f) {
            return Direction.SOUTH;
        } else if (angle == 270f) {
            return Direction.EAST;
        } else if (angle == 90f) {
            return Direction.WEST;
        } else if (angle == 315f) {
            return Direction.NORTHEAST;
        } else if (angle == 45f) {
            return Direction.NORTHWEST;
        } else if (angle == 225f) {
            return Direction.SOUTHEAST;
        } else if (angle == 135f) {
            return Direction.SOUTHWEST;
        } else {
            return NONE;
        }
    }
}
