package sk.tuke.kpi.oop.game.controllers;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Input;
import sk.tuke.kpi.gamelib.KeyboardListener;
import sk.tuke.kpi.oop.game.Keeper;
import sk.tuke.kpi.oop.game.actions.Drop;
import sk.tuke.kpi.oop.game.actions.Shift;
import sk.tuke.kpi.oop.game.actions.Take;
import sk.tuke.kpi.oop.game.actions.Use;
import sk.tuke.kpi.oop.game.items.Collectible;
import sk.tuke.kpi.oop.game.items.Usable;


public class CollectorController implements KeyboardListener {
    //  private Ripley ripley;
    // private Usable usable;
    private Keeper<Collectible> actorr;
 //   private Usable<Collectible> itemfrombag;

    public CollectorController(Keeper<Collectible> actor) {
        this.actorr = actor;
    }

    @Override
    public void keyPressed(@NotNull Input.Key key) {
        if (key == Input.Key.U) {
            for (Actor actor : actorr.getScene().getActors()) {
                if (actor instanceof Usable && actorr.intersects(actor)) {
                    new Use<>((Usable<?>) actor).scheduleOnIntersectingWith(actorr);
                }
            }
        }
        if (key == Input.Key.B && actorr.getContainer().peek() instanceof Usable) {
            new Use<>((Usable<?>) actorr.getContainer().peek()).scheduleOnIntersectingWith(actorr);
        }
        keyPressed1(key);
    }

    public void keyPressed1(@NotNull Input.Key key) {
        switch (key) {
            case ENTER:
                new Take<>(Collectible.class).scheduleOn(actorr);
                break;
            case BACKSPACE:
                new Drop<Collectible>().scheduleOn(actorr);
                break;
            case S:
                new Shift().scheduleOn(actorr);
                break;
            default:
                break;
        }
    }
}

