package sk.tuke.kpi.oop.game.items;

import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.Movable;
import sk.tuke.kpi.oop.game.characters.Alive;
import sk.tuke.kpi.oop.game.characters.Ripley;

public class TeleShoping extends AbstractActor implements Usable<Ripley> {
    private Animation animation = new Animation("sprites/ventilator.png", 32, 32, 0.2f, Animation.PlayMode.LOOP_PINGPONG);

    public TeleShoping() {
        setAnimation(animation);
        animation.stop();
    }

    @Override
    public void useWith(Ripley actor) {
        if (actor != null) {
            if (actor.getMoney() >= 101) {
                actor.setMoney(-101);
                findAndSet(actor);
                actor.getFirearm().reload(9999999);
                actor.setMoney(9999999);
                actor.setSpeed(4);
                animation.play();
                getScene().getGame().getOverlay().drawText("Boosted !!!", 300, 400).showFor(3);
            }
        }
    }

    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }

    public void findAndSet(Ripley ripley) {
        for (Actor actor : ripley.getScene().getActors()) {
            if (actor instanceof Alive) {
                ((Alive) actor).getHealth().refill(9999999);
            }
        }
    }
}
