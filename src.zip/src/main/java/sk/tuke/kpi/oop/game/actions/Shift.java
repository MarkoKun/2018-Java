package sk.tuke.kpi.oop.game.actions;

import sk.tuke.kpi.gamelib.framework.actions.AbstractAction;
import sk.tuke.kpi.oop.game.Keeper;

public class Shift extends AbstractAction<Keeper<?>>{

    public Shift(){

    }

    @Override
    public void execute(float deltaTime){
        if (getActor() == null){
            setDone(true);
            return;
        }
        Keeper<?> ripley = getActor();
            ripley.getContainer().shift();
            setDone(true);
        }

}

