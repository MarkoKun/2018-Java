
package sk.tuke.kpi.oop.game.scenarios;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sk.tuke.kpi.gamelib.*;


import sk.tuke.kpi.oop.game.characters.*;
import sk.tuke.kpi.oop.game.controllers.MovableController;
import sk.tuke.kpi.oop.game.Locker;
import sk.tuke.kpi.oop.game.Ventilator;
import sk.tuke.kpi.oop.game.behaviours.RandomlyMoving;
import sk.tuke.kpi.oop.game.controllers.CollectorController;
import sk.tuke.kpi.oop.game.controllers.ShooterController;
import sk.tuke.kpi.oop.game.items.*;
import sk.tuke.kpi.oop.game.openables.Door;
import sk.tuke.kpi.oop.game.openables.SuperDoor;
import sk.tuke.kpi.oop.game.weapons.Bullet;


public class EscapeRoom implements SceneListener {
    private Ripley ripley;
    public EscapeRoom() {

    }

    @Override
    public void sceneInitialized(@NotNull Scene scene) {
        ripley = scene.getFirstActorByType(Ripley.class);
        /*Hammer hammer = new Hammer();
        AccessCard accessCard = new AccessCard();
        scene.addActor(hammer,ripley.getPosX(),ripley.getPosY()-10);
        scene.addActor(accessCard,ripley.getPosX(),ripley.getPosY()-5);*/
        MovableController movableController = new MovableController(ripley);
        CollectorController collectorController = new CollectorController(ripley);
        ShooterController shooterController = new ShooterController(scene.getFirstActorByType(Armed.class));
        scene.getGame().getOverlay().drawText("Look for hidden locker !!!", 250, 400).showFor(3);
        Input input = scene.getInput();
        input.registerListener(movableController);
        input.registerListener(collectorController);
        input.registerListener(shooterController);
        Game game = scene.getGame();
        if (scene.getFirstActorByType(Ripley.class) != null) {
            ripley.showRipleyState(ripley);
            game.pushActorContainer(ripley.getContainer());
        }
    }

    public void sceneUpdating(@NotNull Scene scene) {
        ripley.showRipleyState(ripley);
        Game game = scene.getGame();
        game.pushActorContainer(ripley.getContainer());
        scene.follow(ripley);
    }
    public static class Factory implements ActorFactory {
        @Nullable
        @Override
        public Actor create(String type, String name) {
            if (name.equals("pc")) {
                return new Pc();
            }
            if (name.equals("canal")) {
                return new TeleShoping();
            }
            if (name.equals("door2")) {
                return new ExpensiveDoor();
            }
            if (name.equals("egg")) {
                return new AlienEggs();
            }
            /*if(name.equals("doorx")){
                return new FinalDoor(name, Door.Orientation.HORIZONTAL);
            }*/
            if (name.equals("hole")) {
                return new Hole();
            }
            if (name.equals("money")) {
                return new Money(0);
            }
            if (name.equals("desk")) {
                return new Desk();
            }
            if (name.equals("door6")) {
                return new LaserDoor();
            }
            if (name.equals("tile")) {
                return new SecretTile(type);
            }
            if (name.equals("win")) {
                return new WinSwich();
            }
            if (name.equals("corpse")) {
                return new Corpse();
            }
            if (name.equals("diode1") || name.equals("diode2") || name.equals("diode3") || name.equals("diode4")) {
                return new Diode(name);
            }
            if (name.equals("energy")) {
                return new Energy();
            }
            if (name.equals("ellen")) {
                return new Ripley();
            }
            if (name.equals("ammo")) {
                return new Ammo();
            }
            if (name.equals("alien")) {
                return new Alien(100, new RandomlyMoving());
            }
            if (name.equals("alien mother")) {
                return new AlienMother(300, null);
            }


            if (name.equals("access card")) {
                return new AccessCard();
            }

            if (name.equals("door1")) {
                return new Door(name, Door.Orientation.HORIZONTAL);
            }
            if (name.equals("door3") || name.equals("door4")) {
                return new SuperDoor(name, Door.Orientation.HORIZONTAL);
            }
            if (name.equals("locker")) {
                return new Locker();
            }

            if (name.equals("ventilator1") || name.equals("ventilator2") || name.equals("ventilator3") || name.equals("ventilator4")) {
                return new Ventilator(type);
            }
            if (name.equals("battery1") || name.equals("battery2") || name.equals("battery3") || name.equals("battery4")) {
                return new Battery();
            }
            if (name.equals("source1")) {
                return new Source();
            }

            return null;

        }
    }
}

