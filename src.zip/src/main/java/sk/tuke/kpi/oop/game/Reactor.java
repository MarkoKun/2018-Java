package sk.tuke.kpi.oop.game;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.oop.game.actions.PerpetualReactorHeating;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;

public class Reactor extends AbstractActor implements Switchable, Repairable {
    private Light light;
    private int temperature;
    private int damage;
    private Animation reactorHot;
    private Animation reactorBroken;
    private Animation reactorOn;
    private Animation reactorOff;
    private int reTemperature;

    //private int temp1 = 0;
    // private int temp2, temp3 = 0;
    private boolean isWorking = false;
    private Animation extinguisherAnimation = new Animation("sprites/reactor_extinguished.png", 80, 80);


    public Reactor() {
        reactorOn = new Animation("sprites/reactor_on.png", 80, 80, 0.1f, Animation.PlayMode.LOOP_PINGPONG);
        reactorOff = new Animation("sprites/reactor.png", 80, 80);
        reactorBroken = new Animation("sprites/reactor_broken.png", 80, 80, 0.1f, Animation.PlayMode.LOOP_PINGPONG);
        reactorHot = new Animation("sprites/reactor_hot.png", 80, 80, 0.1f, Animation.PlayMode.LOOP_PINGPONG);
        temperature = 0;
        damage = 0;
        //normalAnimation = new Animation("sprites/reactor_on.png",80,80,0.1f,Animation.PlayMode.LOOP_PINGPONG);
        isWorking = false;
        setAnimation(reactorOff);
    }

    @Override
    public void turnOn() {
        if (!isOn()&&!getAnimation().equals(reactorBroken)) {
                isWorking = true;
                updateAnimation(temperature);
            }
    }

    @Override
    public void turnOff() {
        if (isOn()) {
            isWorking = false;
            updateAnimation(temperature);
        }
        /*if (temperature < 6000){
            normalAnimation = new Animation("sprites/reactor.png", 80, 80);
            setAnimation(normalAnimation);
        }*/

    }

    private void updateAnimation(int temperature) {
        if (!isOn() && temperature < 6000) {
            setAnimation(reactorOff);
        }
        if (temperature < 4000 && isOn()) {
            setAnimation(reactorOn);
        }
        if (temperature >= 4000 && temperature < 6000 && isOn()) {
            setAnimation(reactorHot);

        }
        if (temperature >= 6000) {
            setAnimation(reactorBroken);

        }
    }


    public int getTemperature() {
        return temperature;
    }

    public int getDamage() {
        return damage;
    }

    public void increaseTemperature(int increment) {
        if (increment < 0 ||  !isOn()) {
            return;
        }
        if (damage < 33)
            temperature += increment;
        else if(damage < 67)
            temperature += (1.5 * increment);
        else
            temperature += (2 * increment);

        if ((temperature - 2000) /40 > damage) {
            damage = (temperature - 2000) / 40;
        }

        if (damage > 100) {
            damage = 100;
        }

        if (temperature > 6000){
            damage = 100;
            turnOff();
        }
        updateAnimation(temperature);
    }


    public void decreaseTemperature(int decrement) {
        if (isOn()) {
            if (decrement < 0) {
                return;
            }
            if (damage < 100) {
                if (damage < 50) {
                    temperature = temperature - decrement;
                }
                if (damage >= 50) {
                    temperature = temperature - (decrement / 2);
                }
                if (temperature <= 0) {
                    temperature = 0;
                }
                updateAnimation(temperature);

            }

        }
    }

    public boolean repair() {
        if (damage == 0 || damage == 100) {
            return false;
        } else {

            if ((damage > 0) && (damage < 100)) {
                damage = damage - 50;
            }
            if (damage < 0) {
                damage = 0;
            }
            reTemperature = damage *40 + 2000;
            if(reTemperature < temperature && reTemperature > 0){
                temperature = reTemperature;
            }
            updateAnimation(temperature);
            return true;

        }
    }


    @Override
    public boolean isOn() {
        return isWorking;
    }

    public void addLight(Light light) {
        this.light = light;

    }

    public void removeLight(Light light) {
        Scene scene = getScene();
        assert scene != null;
        scene.removeActor(this.light);
    }

    public boolean extinguish() {
        if (damage == 100) {

            temperature = 4000;
            setAnimation(extinguisherAnimation);
            return true;

        } else {
            return false;
        }
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);

        new PerpetualReactorHeating(1).scheduleOn(this);
        if (getTemperature() > 6000) {
            temperature = 6000;
            updateAnimation(temperature);
        }
    }


}






