package sk.tuke.kpi.oop.game.characters;

import sk.tuke.kpi.gamelib.framework.AbstractActor;

import java.util.ArrayList;
import java.util.List;

public class Health extends AbstractActor {
    private int start;
    private int max;
    private int temp;
    private List<ExhaustionEffect> mylist = new ArrayList<>();

    public Health(int starthp, int maxhp) {
        start = starthp;
        max = maxhp;
    }

    public Health(int hp) {
        start = hp;
        max = hp;

    }
    public int getValue() {
        return start;
    }
    public void refill(int amount) {
        start += amount;
        if (start > max) {
            start = max;
        }
    }
    public void restore() {
        start = max;
    }
    public void drain(int amount) {
        start -= amount;
        if (start <= 0) {
            start = 0;
            if (temp == 0) {
                mylist.forEach(ExhaustionEffect::apply);
                temp = 1;
            }
        }


    }
    public void exhaust() {
        start = 0;
        drain(0);
    }
    public void onExhaustion(ExhaustionEffect effect) {
        mylist.add(effect);

    }
    @FunctionalInterface
    public interface ExhaustionEffect {
        void apply();
    }
}
