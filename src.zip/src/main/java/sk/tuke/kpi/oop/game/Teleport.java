package sk.tuke.kpi.oop.game;

public class Teleport {
}
