package sk.tuke.kpi.oop.game.items;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.characters.Ripley;

public class Source extends AbstractActor implements Usable<Ripley> {
    private int lives;

    public Source() {
        lives = 3;
        Animation animation = new Animation("sprites/box_large.png", 16, 16);
        setAnimation(animation);
    }

    @Override
    public void useWith(Ripley actor) {
        if (actor != null) {
            if (lives == 3) {
                actor.getScene().addActor(new Hammer(), actor.getPosX(), actor.getPosY() - 10);
            } else if (lives == 2) {
                actor.getScene().addActor(new Ammo(), actor.getPosX(), actor.getPosY() - 17);
            } else if (lives == 1) {
                actor.getScene().addActor(new Energy(), actor.getPosX() + 3, actor.getPosY() - 22);
            }
            lives--;
            getScene().getGame().getOverlay().drawText("There is a body on the ground, let's check it out!!!", 100, 400).showFor(5);

        }
    }

    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }


}
