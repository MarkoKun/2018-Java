package sk.tuke.kpi.oop.game.items;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.actions.Wait;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.Ventilator;
import sk.tuke.kpi.oop.game.characters.Ripley;


public class Battery extends AbstractActor {
    private Animation animation = new Animation("sprites/lift.png", 48, 48);
    private int rasp;

    public Battery() {
        setAnimation(animation);
        rasp = 0;
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        getScene().getMessageBus().subscribe(Ventilator.VENTILATOR3_ON, diode -> fully1());
        new Loop<>(
            new ActionSequence<>(
                new Invoke<>(() -> fully(scene.getFirstActorByType(Ripley.class))),
                new Wait<>(2)
            )
        ).scheduleOn(this);
    }

    public void fully(Ripley ripley) {
        if (ripley != null) {
            if (ripley.intersects(this) && rasp == 1) {
                ripley.getHealth().refill(5);
                ripley.getFirearm().reload(5);
            }
        }
    }

    public void fully1() {
        rasp = 1;
    }
}
