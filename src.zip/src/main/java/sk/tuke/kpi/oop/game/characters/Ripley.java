package sk.tuke.kpi.oop.game.characters;

import sk.tuke.kpi.gamelib.ActorContainer;
import sk.tuke.kpi.gamelib.Game;
import sk.tuke.kpi.gamelib.GameApplication;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.gamelib.messages.Topic;
import sk.tuke.kpi.oop.game.Direction;
import sk.tuke.kpi.oop.game.Keeper;
import sk.tuke.kpi.oop.game.Movable;
import sk.tuke.kpi.oop.game.items.Backpack;
import sk.tuke.kpi.oop.game.items.Collectible;
import sk.tuke.kpi.oop.game.items.Money;
import sk.tuke.kpi.oop.game.weapons.Firearm;
import sk.tuke.kpi.oop.game.weapons.Gun;

public class Ripley extends AbstractActor implements Movable, Keeper<Collectible>, Alive, Armed, Casher {
    public static final Topic<Ripley> RIPLEY_DIED = Topic.create("ripley died", Ripley.class);
    private int speed;
    private Backpack backpack;
    private int ammmo;
    private Health health;
    private Animation ripleyAnimation;
    private Animation deadRipley;
    private Firearm gun;
    private Money money;
    private int money1;

    public Ripley() {
        super("Ellen");
        deadRipley = new Animation("sprites/player_die.png", 32, 32, 0.1f, Animation.PlayMode.ONCE);
        ripleyAnimation = new Animation("sprites/player.png", 32, 32, 0.1f, Animation.PlayMode.LOOP_PINGPONG);
        setAnimation(ripleyAnimation);
        ripleyAnimation.pause();
        speed = 2;
        ammmo = 0;
        money1 = 0;
        backpack = new Backpack("Ripley's backpack", 10);
        gun = new Gun(0, 9999999);
        health = new Health(1, 9999999);
        money = new Money(0);
        health.onExhaustion(() -> {
            speed = 0;
            setAnimation(deadRipley);
            getScene().getMessageBus().publish(RIPLEY_DIED, this);
            getScene().getGame().getOverlay().drawText("Level failed!! Ripley is dead.", 300, 400).showFor(100000);
            getScene().cancelActions(this);
        });
    }



    public int getAmmo() {
        ammmo = gun.getAmmo();
        return ammmo;
    }

    public void setAmmo(int ammo) {
        this.ammmo += ammo;
        if (this.ammmo > 9999999) {
            this.ammmo = 9999999;
        }

    }

    @Override
    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    @Override
    public void startedMoving(Direction direction) {

        if (direction == Direction.NORTH) {
            ripleyAnimation.setRotation(0);
            ripleyAnimation.play();
        }

        if (direction == Direction.SOUTH) {
            ripleyAnimation.setRotation(180);
            ripleyAnimation.play();
        }

        if (direction == Direction.EAST) {
            ripleyAnimation.setRotation(270);
            ripleyAnimation.play();
        }
        if (direction == Direction.WEST) {
            ripleyAnimation.setRotation(90);
            ripleyAnimation.play();
        }
    }


    @Override
    public void stoppedMoving() {
        ripleyAnimation.stop();
    }

    @Override
    public ActorContainer<Collectible> getContainer() {
        return backpack;
    }

    public void showRipleyState(Ripley ripley) {
        int windowHeight = ripley.getScene().getGame().getWindowSetup().getHeight();
        int topOffset = GameApplication.STATUS_LINE_OFFSET;
        int yTextPos = windowHeight - topOffset;
        ripley.getScene().getGame().getOverlay().drawText("Energy : " + health.getValue(), 100, yTextPos);
        ripley.getScene().getGame().getOverlay().drawText("Ammo : " + ripley.getAmmo(), 350, yTextPos);
        ripley.getScene().getGame().getOverlay().drawText("Money : " + ripley.getMoney(), 600, yTextPos);
        Game game = ripley.getScene().getGame();
        game.pushActorContainer(ripley.getContainer());
    }

    @Override
    public Health getHealth() {
        return health;
    }

    @Override
    public Firearm getFirearm() {
        return gun;
    }

    @Override
    public void setFirearm(Firearm firearm) {
        this.gun = firearm;
    }

    @Override
    public int getMoney() {
        return money1;
    }

    @Override
    public void setMoney(int money) {
        money1 += money;
        if (money1 > 9999999) {
            money1 = 9999999;
        }
    }
}
