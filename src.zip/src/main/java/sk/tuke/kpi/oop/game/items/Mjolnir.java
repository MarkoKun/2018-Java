package sk.tuke.kpi.oop.game.items;
public class Mjolnir extends Hammer {
    public Mjolnir(){
        super(4);
    }
}
