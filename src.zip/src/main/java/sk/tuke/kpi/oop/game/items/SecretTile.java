package sk.tuke.kpi.oop.game.items;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.gamelib.messages.Topic;
import sk.tuke.kpi.oop.game.characters.Ripley;

public class SecretTile extends AbstractActor implements Usable<Ripley> {
    public static final Topic<SecretTile> SecretTile1_ON = Topic.create("SecretTile1 on", SecretTile.class);
    public static final Topic<SecretTile> SecretTile2_ON = Topic.create("SecretTile2 on", SecretTile.class);
    public static final Topic<SecretTile> SecretTile3_ON = Topic.create("SecretTile3 on", SecretTile.class);
    public static final Topic<SecretTile> SecretTile4_ON = Topic.create("SecretTile4 on", SecretTile.class);
    public static final Topic<SecretTile> SecretTile5_ON = Topic.create("SecretTile5 on", SecretTile.class);
    public static final Topic<SecretTile> SecretTile6_ON = Topic.create("SecretTile6 on", SecretTile.class);
    private String myType;

    public SecretTile(String type) {
        this.myType = type;
        setAnimation(new Animation("sprites/life.png", 16, 16));
    }


    public void mindLuck(Ripley actor) {
        if (actor != null) {
            if (myType.equals("t1")) {
                actor.getScene().getMessageBus().publish(SecretTile1_ON, this);
                getScene().getGame().getOverlay().drawText("Good job, press them all !!!", 300, 400).showFor(2);

                this.getAnimation().setRotation(180);
            } else if (myType.equals("t2")) {
                actor.getScene().getMessageBus().publish(SecretTile2_ON, this);
                getScene().getGame().getOverlay().drawText("Good job, press them all !!!", 300, 400).showFor(2);

                this.getAnimation().setRotation(180);
            } else if (myType.equals("t3")) {
                actor.getScene().getMessageBus().publish(SecretTile3_ON, this);
                getScene().getGame().getOverlay().drawText("Good job, press them all !!!", 300, 400).showFor(2);

                this.getAnimation().setRotation(180);
            } else if (myType.equals("t4")) {
                actor.getScene().getMessageBus().publish(SecretTile4_ON, this);
                getScene().getGame().getOverlay().drawText("Good job, press them all !!!", 300, 400).showFor(2);

                this.getAnimation().setRotation(180);
            } else if (myType.equals("t5")) {
                actor.getScene().getMessageBus().publish(SecretTile5_ON, this);
                getScene().getGame().getOverlay().drawText("Good job, press them all !!!", 300, 400).showFor(2);

                this.getAnimation().setRotation(180);
            } else if (myType.equals("t6")) {
                actor.getScene().getMessageBus().publish(SecretTile6_ON, this);
                getScene().getGame().getOverlay().drawText("Good job, lets win this game now, press the secret button and leave this place !", 300, 400).showFor(2);

                this.getAnimation().setRotation(180);
            }

        }
    }


    @Override
    public void useWith(Ripley actor) {
        mindLuck(actor);
    }

    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }
}
