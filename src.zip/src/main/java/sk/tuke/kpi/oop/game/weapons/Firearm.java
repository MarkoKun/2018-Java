package sk.tuke.kpi.oop.game.weapons;

public abstract class Firearm {
    private int maxAmmo;
    private int ammo;

    public Firearm(int initAmmo, int maxAmmo) {
        this.ammo = initAmmo;
        this.maxAmmo = maxAmmo;
    }

    public Firearm(int initAmmo) {
        this.ammo = initAmmo;
        this.maxAmmo = initAmmo;
    }


    public void reload(int newAmmo) {
        ammo += newAmmo;
        if (ammo > maxAmmo) {
            ammo = maxAmmo;
        }
    }

    public Fireable fire() {
        if (ammo <= 0) {
            return null;
        } else {
            ammo = getAmmo() - 1;

            return createBullet();

        }
    }

    public int getAmmo() {
        return this.ammo;
    }

    protected abstract Fireable createBullet();

}
