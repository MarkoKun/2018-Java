package sk.tuke.kpi.oop.game.openables;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.gamelib.map.MapTile;
import sk.tuke.kpi.gamelib.messages.Topic;
import sk.tuke.kpi.oop.game.items.Usable;
public class Door extends AbstractActor implements Openable, Usable<Actor> {
    private Animation doorr = new Animation("sprites/vdoor.png", 16, 32, 0.1f);
    private Animation doorh = new Animation("sprites/hdoor.png", 32, 16, 0.1f);
    private boolean open;
    public static final Topic<Door> DOOR_OPENED = Topic.create("door opened", Door.class);
    public static final Topic<Door> DOOR_CLOSED = Topic.create("door closed", Door.class);

    public enum Orientation {VERTICAL, HORIZONTAL}

    public Door(String namee, Orientation orientation) {
        super(namee);
        if (orientation == Orientation.VERTICAL) {
            setAnimation(doorr);
            doorr.stop();

        } else if (orientation == Orientation.HORIZONTAL) {
            setAnimation(doorh);
            doorh.stop();
        }
        open = false;
        // this.close();
    }

    @Override
    public void open() {
        open = true;
        if (this.getAnimation() == doorr) {
            doorr.setPlayMode(Animation.PlayMode.ONCE_REVERSED);
            getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16 + 1).setType(MapTile.Type.CLEAR);
            getScene().getMessageBus().publish(DOOR_OPENED, this);
        } else if (this.getAnimation() == doorh) {
            doorh.setPlayMode(Animation.PlayMode.ONCE_REVERSED);
            getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16 + 1, this.getPosY() / 16).setType(MapTile.Type.CLEAR);
            getScene().getMessageBus().publish(DOOR_OPENED, this);
        }
    }
    @Override
    public void close() {
        open = false;
        if (this.getAnimation() == doorr) {
            doorr.setPlayMode(Animation.PlayMode.ONCE);
            if (getScene().getMap() == null) {
                return;
            }
            getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16).setType(MapTile.Type.WALL);
            getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16 + 1).setType(MapTile.Type.WALL);
            getScene().getMessageBus().publish(DOOR_CLOSED, this);
        } else if (this.getAnimation() == doorh) {
            if (getScene().getMap() == null) {
                return;
            }
            doorh.setPlayMode(Animation.PlayMode.ONCE);
            getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16).setType(MapTile.Type.WALL);
            getScene().getMap().getTile(this.getPosX() / 16 + 1, this.getPosY() / 16).setType(MapTile.Type.WALL);
            getScene().getMessageBus().publish(DOOR_CLOSED, this);
        }
    }
    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        this.close();
    }
    @Override
    public boolean isOpen() {
        return open;
    }

    @Override
    public void useWith(Actor actor) {
        if (actor != null) {
            if (isOpen()){
                close();
            } else {
                open();

            }
        }
    }

    @Override
    public Class<Actor> getUsingActorClass() {
        return Actor.class;
    }


}
