package sk.tuke.kpi.oop.game.characters;

import sk.tuke.kpi.gamelib.Actor;

public interface Casher extends Actor {
    int getMoney();

    void setMoney(int money);
}
