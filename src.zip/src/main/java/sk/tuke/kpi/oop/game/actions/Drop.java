package sk.tuke.kpi.oop.game.actions;

import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.actions.AbstractAction;
import sk.tuke.kpi.oop.game.Keeper;


public class Drop<T extends Actor> extends AbstractAction<Keeper<T>>{
    public Drop(){
        //finish = false;
    }

    @Override
    public void execute(float deltaTime) {
        if (getActor() == null) {
            setDone(true);
            //isDone();
            return;
        }

        Keeper<T> ripley = getActor();

        if ((ripley.getContainer().peek() == null)) {
            setDone(true);
            return;
        }
        Scene scene = ripley.getScene();
        scene.addActor(ripley.getContainer().peek(), ripley.getPosX(), ripley.getPosY());
        ripley.getContainer().remove(ripley.getContainer().peek());

        setDone(true);
    }
   /* @Override
    public boolean isDone() {
        return finish;
    }*/

   /* @Override
    public void reset() {
        finish = false;
    }
*/

}
