package sk.tuke.kpi.oop.game.behaviours;

import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.actions.Wait;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.oop.game.Direction;
import sk.tuke.kpi.oop.game.Movable;
import sk.tuke.kpi.oop.game.actions.Move;

import java.util.Random;

public class RandomlyMoving implements Behaviour<Movable> {
    private Move<Movable> move;
    private Movable actor;
    private int randomNumber;

    public RandomlyMoving() {

    }

    @Override
    public void setUp(Movable actor) {
        this.actor = actor;
        if (actor != null) {
            this.ramdomlyMooving();
        }
    }

    private void ramdomlyMooving() {
        new Loop<>(
            new ActionSequence<>(
                new Wait<>(getRandomNumber()),
                new Invoke<>(this::moveOfAlien))
        ).scheduleOn(actor);
    }

    private void moveOfAlien() {
        Random random = new Random();
        Direction direction = Direction.values()[random.nextInt(Direction.values().length)];
        actor.getAnimation().setRotation(direction.getAngle());
        if (move != null && actor != null) {
            move.stop();
        }
        move = new Move<Movable>(direction, randomNumber);
        move.scheduleOn(actor);

    }

    private int getRandomNumber() {
        Random random = new Random();
        return randomNumber = random.nextInt(3) + 1;
    }

}
