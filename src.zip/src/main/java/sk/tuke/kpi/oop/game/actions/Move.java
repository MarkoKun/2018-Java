package sk.tuke.kpi.oop.game.actions;

import org.jetbrains.annotations.Nullable;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.Action;
import sk.tuke.kpi.gamelib.map.SceneMap;
import sk.tuke.kpi.oop.game.Direction;
import sk.tuke.kpi.oop.game.Movable;
import sk.tuke.kpi.oop.game.weapons.Bullet;

import java.util.List;


public class Move<A extends Movable> implements Action<A> {
    private A movable;
    private Direction direction;
    private boolean on;
    private float time;
    private float temp1;


    public Move(Direction direction, float duration) {
        time = duration;
        this.direction = direction;

    }

    public Move(Direction direction) {
        this.direction = direction;
        time = 0;
    }

    @Nullable
    @Override
    public A getActor() {
        return movable;
    }

    @Override
    public void setActor(@Nullable A movable) {
        this.movable = movable;
    }

    @Override
    public boolean isDone() {
        return on;
    }

    @Override
    public void execute(float deltaTime) {
        if (deltaTime <= 0) {
            on = true;
            return;
        }
        if (this.movable == null) {
            on = true;
            return;
        }
        this.temp1 += deltaTime;
        if (time - temp1 <= 1e-5) {
            on = true;
            return;
        }
        this.movable.startedMoving(this.direction);
        int speed = movable.getSpeed();
        int dx = direction.getDx();
        int dy = direction.getDy();
        dx *= speed;
        dy *= speed;
        movable.setPosition(movable.getPosX() + dx, movable.getPosY() + dy);
        SceneMap sceneMap = getActor().getScene().getMap();
        if (sceneMap.intersectsWithWall(getActor())){
            movable.setPosition(movable.getPosX() - dx, movable.getPosY() - dy);
            movable.collidedWithWall();

        }
    }
    @Override
    public void reset() {
        on = false;
    }

    public void stop(){
        on = true;
        if (movable != null)
            movable.stoppedMoving();
    }



}
