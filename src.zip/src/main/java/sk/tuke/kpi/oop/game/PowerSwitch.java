package sk.tuke.kpi.oop.game;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;

public class PowerSwitch extends AbstractActor{

    private Animation controllerAnimation = new Animation("sprites/switch.png", 16, 16);;
    private Switchable switchable;
   // private boolean isWorking;
    public PowerSwitch(Switchable switchable){
        setAnimation(controllerAnimation);
        this.switchable = switchable;
    }

    public Switchable getDevice(){
        return switchable;
    }


    public void switchOn(){
        if(switchable == null) {
            return;
        }
        switchable.turnOn();
    }
    public void switchOff(){
        if(switchable == null) {
            return;
        }
        switchable.turnOff();
    }



}
