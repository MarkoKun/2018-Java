package sk.tuke.kpi.oop.game.weapons;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.Direction;
import sk.tuke.kpi.oop.game.Movable;
import sk.tuke.kpi.oop.game.Ventilator;
import sk.tuke.kpi.oop.game.characters.Alive;
import sk.tuke.kpi.oop.game.items.Pc;

import java.util.List;

public class Bullet extends AbstractActor implements Fireable, Movable {
    private int speed;
    private Animation animation = new Animation("sprites/bullet.png", 16, 16);
    private Animation animation1 = new Animation("sprites/energy_bullet.png", 16, 16);

    public Bullet() {
        speed = 5;
        setAnimation(animation);
    }

    @Override
    public int getSpeed() {
        return speed;
    }


    @Override
    public void startedMoving(Direction direction) {
        animation.setRotation(direction.getAngle());
    }


    public void blabla() {
        Scene scene = getScene();
        List<Actor> alivers;
        alivers = scene.getActors();
        for (Actor actor : alivers) {
            if (actor instanceof Alive && this.intersects(actor) && !actor.getName().equals("Ellen")) {
                scene.removeActor(this);
                ((Alive) actor).getHealth().drain(10);
            }
        }
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        new Loop<>(
            new ActionSequence<>(
                new Invoke<>(this::blabla)
            )
        ).scheduleOn(this);
    }

    @Override
    public void collidedWithWall() {
        getScene().removeActor(this);
    }

    public void setAnim() {
        setAnimation(animation1);
    }

}
