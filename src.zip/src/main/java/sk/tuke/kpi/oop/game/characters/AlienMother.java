package sk.tuke.kpi.oop.game.characters;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.ActionSequence;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.actions.Wait;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.behaviours.Behaviour;


public class AlienMother extends Alien {
    private Health health;
    private int hp;
    private boolean dead;
    private Animation animation;

    public AlienMother(int healthValue, Behaviour<? super Alien> behaviour) {
        super(healthValue, behaviour);
        animation = new Animation("sprites/mother.png", 112, 162, 0.2f);
        setAnimation(animation);
        health = new Health(healthValue);
        hp = healthValue;
        dead = false;

    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        new Loop<>(
            new ActionSequence<>(
                new Invoke<>(this::changeAnima),
                new Invoke<>(this::huntingMode),
                new Invoke<>(this::drain),
                new Wait<>(0.1f))
        ).scheduleOn(this);
    }

    public void huntingMode() {
        if (hp != health.getValue()) {
            Ripley ripley = getScene().getFirstActorByType(Ripley.class);
            haunt(ripley);
        }
    }

    public void haunt(Ripley ripley) {
        if (ripley.getPosX() != getPosX() || ripley.getPosY() != getPosY()) {
            if (getPosX() > ripley.getPosX()) {
                setPosition(getPosX() - 1, getPosY());
            } else {
                setPosition(getPosX() + 1, getPosY());
            }
            if (getPosY() > ripley.getPosY()) {
                setPosition(getPosX(), getPosY() - 1);
            } else {
                setPosition(getPosX(), getPosY() + 1);
            }
        }
    }

    public void changeAnima() {
        if (this.getHealth().getValue() <= 0) {
            animation.stop();
            animation.setRotation(45);
            /*getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16+1).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16+2).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16+3).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16, this.getPosY() / 16+4).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+1, this.getPosY() / 16).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+1, this.getPosY() / 16+1).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+1, this.getPosY() / 16+2).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+1, this.getPosY() / 16+3).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+1, this.getPosY() / 16+4).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+2, this.getPosY() / 16).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+2, this.getPosY() / 16+1).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+2, this.getPosY() / 16+2).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+2, this.getPosY() / 16+3).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+2, this.getPosY() / 16+4).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+3, this.getPosY() / 16).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+3, this.getPosY() / 16+1).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+3, this.getPosY() / 16+2).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+3, this.getPosY() / 16+3).setType(MapTile.Type.CLEAR);
            getScene().getMap().getTile(this.getPosX() / 16+3, this.getPosY() / 16+4).setType(MapTile.Type.CLEAR);*/


            dead = true;
        }
    }

    public void drain() {
        if (!dead) {
            for (Actor someActor : getScene().getActors()) {
                if (someActor instanceof Casher && someActor.intersects(this)) {
                    ((Alive) someActor).getHealth().drain(10);
                }

            }
        }
    }

    @Override
    public Health getHealth() {
        return this.health;
    }
}
