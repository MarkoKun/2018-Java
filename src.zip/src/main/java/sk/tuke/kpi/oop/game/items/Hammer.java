package sk.tuke.kpi.oop.game.items;

import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.Repairable;

public class Hammer extends BreakableTool<Repairable> implements Collectible {
    private int use_left;
    private Animation normalAnimation = new Animation("sprites/hammer.png", 16, 16);
    public Hammer() {
        super(1);
        setAnimation(normalAnimation);
    }
    public Hammer(int use_left) {
        super(use_left);
        setAnimation(normalAnimation);
        //use_left = 1;

    }
    public int getUseLeft() {
        return use_left;
    }
    @Override
    public void useWith(Repairable repairable) {
        if (repairable != null && repairable.repair()) {
            super.useWith(repairable);
        }
    }
    @Override
    public Class<Repairable> getUsingActorClass() {
        return Repairable.class;
    }
}

