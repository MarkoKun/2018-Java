package sk.tuke.kpi.oop.game;

import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;

public class Light extends AbstractActor implements Switchable,EnergyConsumer{
    private Animation lightAnimationOn = new Animation("sprites/light_on.png", 16, 16);
    private Animation lightAnimationOff = new Animation("sprites/light_off.png", 16, 16);
     private boolean isFlow;
     private boolean power;

    public Light(){
        isFlow = false;
        setAnimation(lightAnimationOff);
    }

    public void turnOn(){
        power = true;
        if (isFlow) {
            setAnimation(lightAnimationOn);
        }
    }
    public void turnOff(){
        power = false;
        if (!isFlow) {
            setAnimation(lightAnimationOff);
        }
    }
    public boolean isOn(){return power;}



    public void toggle(){
        if (isOn()) {
            power = false;
            setAnimation(lightAnimationOff);
        }else if (!isOn()){
            power = true;
            setAnimation(lightAnimationOn);
        }

    }
    @Override
    public void setPowered(boolean isFlow){
        this.isFlow = isFlow;
        if (isFlow && isOn()){
            setAnimation(lightAnimationOn);
        }else {
            setAnimation(lightAnimationOff);
        }
    }
}


