package sk.tuke.kpi.oop.game;

import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.graphics.Animation;
import sk.tuke.kpi.oop.game.characters.Ripley;
import sk.tuke.kpi.oop.game.items.Hammer;
import sk.tuke.kpi.oop.game.items.Usable;

public class Locker extends AbstractActor implements Usable<Ripley> {
    private Animation lockerr = new Animation("sprites/locker.png", 16, 16);
    private int lives;
    private Hammer hammer;
    public Locker(){
        lives=1;
        setAnimation(lockerr);
    }
    public void useWith(Ripley ripley) {
        if (lives == 1) {
            Scene scene = ripley.getScene();
            hammer = new Hammer();
            scene.addActor(hammer,ripley.getPosX(),ripley.getPosY());
            lives--;
        }
    }



    @Override
    public Class<Ripley> getUsingActorClass() {
        return Ripley.class;
    }
}
