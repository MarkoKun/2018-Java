/*
package sk.tuke.kpi.oop.game.scenarios;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import sk.tuke.kpi.gamelib.*;
import sk.tuke.kpi.oop.game.controllers.MovableController;
import sk.tuke.kpi.oop.game.Locker;
import sk.tuke.kpi.oop.game.openables.Door;
import sk.tuke.kpi.oop.game.openables.LockedDoor;
import sk.tuke.kpi.oop.game.Ventilator;
import sk.tuke.kpi.oop.game.characters.Ripley;
import sk.tuke.kpi.oop.game.controllers.CollectorController;
import sk.tuke.kpi.oop.game.items.AccessCard;
import sk.tuke.kpi.oop.game.items.Energy;

public class MissionImpossible implements SceneListener {
    private Ripley ripley;
    private Boolean letsdrainenergy;

    public MissionImpossible(){
        letsdrainenergy = false;
    }

   */
/* @Override
    public void sceneInitialized(@NotNull Scene scene) {
        ripley = scene.getFirstActorByType(Ripley.class);
        MovableController keyboardController = new MovableController(ripley);
        CollectorController collectorController = new CollectorController(ripley);
        Input input = scene.getInput();
        input.registerListener(keyboardController);
        input.registerListener(collectorController);
        ripley.showRipleyState(ripley);
        Game game = scene.getGame();
        game.pushActorContainer(ripley.getContainer());
    }*//*


 */
/* @Override
    public void sceneUpdating(@NotNull Scene scene) {
        ripley.showRipleyState(ripley);
        Game game = scene.getGame();
        game.pushActorContainer(ripley.getContainer());
        scene.follow(ripley);
       // Door door = scene.getFirstActorByType(Door.class);
        scene.getMessageBus().subscribe(Door.DOOR_OPENED, door1 -> letsdrainenergy=true);
        if (letsdrainenergy){
            ripley.setEnergy(ripley.getEnergy()-1);
        }
    }*//*

 */
/* new When<>(
                (action) -> door.intersects(ripley) && !door.isOpen(),
                new ActionSequence<>(
                    new Invoke<Actor>(() -> door.useWith(ripley)),
                    new Wait<>(2),
                    new Invoke<>(door::close)
                )

            ).scheduleOn(door);*//*

 */
/*  public static class Factory implements ActorFactory {

        @Nullable
        @Override
        public Actor create(String type, String name) {

            if (name.equals("energy")){
                return new Energy();
            }
            if (name.equals("ellen")){
                return new Ripley();
            }
            if (name.equals("door")){
                return new LockedDoor();
            }
            if (name.equals("access card")){
                return new AccessCard();
            }
            if (name.equals("locker")){
                return new Locker();
            }
            if (name.equals("ventilator")){
                return new Ventilator();
            }

            return null;

        }
    }*//*


}
*/
