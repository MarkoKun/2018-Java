/*

package sk.tuke.kpi.oop.game.items;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Actor;
import sk.tuke.kpi.gamelib.Scene;

import sk.tuke.kpi.oop.game.Keeper;
import sk.tuke.kpi.oop.game.openables.Door;

public class FinalDoor extends Door implements Usable<Actor> {
    public FinalDoor(String namee, Orientation orientation) {
        super(namee, orientation);
    }

    @Override
    public void useWith(Actor actor) {
        if (actor != null) {
            for (Actor actor1 : actor.getScene().getActors()) {
                if (actor1 instanceof Keeper<?>) {
                    actor.getScene().getMessageBus().subscribe(SecretTile.SecretTileAllOn, bla -> open());
                }
            }
        }
    }

    @Override
    public void addedToScene(@NotNull Scene scene) {
        super.addedToScene(scene);
        this.close();
    }
}

*/
