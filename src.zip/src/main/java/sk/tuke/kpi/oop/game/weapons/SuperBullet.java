package sk.tuke.kpi.oop.game.weapons;

public class SuperBullet extends Bullet {

}
