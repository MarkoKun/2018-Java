package sk.tuke.kpi.oop.game;

import org.jetbrains.annotations.NotNull;
import sk.tuke.kpi.gamelib.Scene;
import sk.tuke.kpi.gamelib.actions.Invoke;
import sk.tuke.kpi.gamelib.framework.AbstractActor;
import sk.tuke.kpi.gamelib.framework.actions.Loop;
import sk.tuke.kpi.gamelib.graphics.Animation;

public class TimeBomb extends AbstractActor {
    private float time;
    private boolean isBombOn = false;
    private Animation offBomb = new Animation("sprites/bomb.png", 16, 16);
    private Animation onBomb = new Animation("sprites/bomb_activated.png", 16, 16);
    private Animation explodingBomb = new Animation("sprites/small_explosion.png", 16, 16,0.2f, Animation.PlayMode.ONCE);

    public TimeBomb(float time){
        isBombOn = false;
        this.time = time+65;
        setAnimation(offBomb);

    }
    public void activate(){
        isBombOn = true;
        setAnimation(onBomb);

    }
    public void work(){

        if (isActivated()) {
            time--;
        }

            if(time <= 65) {
                setAnimation(explodingBomb);
                if (time == -1) {
                    getScene().removeActor(this);

                }
                if (time <= 0) {
                    time = 0;

                }
            }
        }

    public boolean isActivated(){
        return isBombOn;
    }
    @Override
    public void addedToScene(@NotNull Scene scene){
        super.addedToScene(scene);
        new Loop<>(new Invoke<>(this::work)).scheduleOn(this);
    }
}
