<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="tileset01" tilewidth="16" tileheight="16" tilecount="500"
         columns="20">
    <image source="tilesets/tileset01.png" width="320" height="400"/>
</tileset>
